from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import DetailView, TemplateView
from django.views.generic.edit import UpdateView
from django.contrib.auth import authenticate
from .forms import SimpleUserCreationForm

from .models import User
# Create your views here.

class ProfileView(LoginRequiredMixin, DetailView):
    template_name = "registration/profile.html"
    queryset = User.objects.all()


def register(request):
    form = SimpleUserCreationForm()
    if request.method == 'POST':
        form = SimpleUserCreationForm(request.POST)
        if form.is_valid():
            u = form.save()
            u = form.is_valid()
            authenticate(u)
            return redirect('/')
        else:
            return render(request, 'registration/register.html', {"form": form})
    return render(request, 'registration/register.html', {"form": form})


class Logout(TemplateView):
    template_name = 'index.html'


class ProfileEditView(UpdateView):
    model = User
    template_name = 'registration/profile_edit.html'
    fields = ['first_name', 'last_name', 'image', 'bio', 'address', 'email']
    success_url = reverse_lazy('main:home')
