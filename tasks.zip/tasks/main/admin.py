from django.contrib import admin
from .models import *
# Register your models here.
@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
  list_display = ['title']
  prepopulated_fields = {"slug":('title',)}

@admin.register(Tag)
class TagAdmin(admin.ModelAdmin):
  list_display = ['title']
  prepopulated_fields = {"slug":('title',)}

@admin.register(Status)
class StatusAdmin(admin.ModelAdmin):
  list_display = ['title']
  prepopulated_fields = {"slug":('title',)}
  
@admin.register(Notelist)
class NotelistAdmin(admin.ModelAdmin):
  list_display = ['name', 'description']

admin.site.register(Done)


  
  