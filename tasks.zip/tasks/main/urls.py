from django.urls import path
from .import views

app_name='main'

urlpatterns = [
  path('', views.HomePageView.as_view(),name='home'),
  path('add/',views.AddView.as_view(),name='add'),
  path('update/<pk>',views.UpdateView.as_view(), name='update'),
  path('done/<int:pk>/', views.done, name='done'),
  path('delete/<pk>/', views.delete,name='delete'),
  path('help/',views.HelpPage.as_view(), name='help'),

]