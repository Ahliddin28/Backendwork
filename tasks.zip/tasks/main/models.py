from django.db import models
from ckeditor.fields import RichTextField
from accounts.models import User
from django.template.defaultfilters import slugify


class Category(models.Model):
    title = models.CharField(max_length=100)
    slug = models.SlugField(unique=True)

    def __str__(self):
        return str(self.title)


class Status(models.Model):
    title = models.CharField(max_length=100)
    slug = models.CharField(max_length=100)

    def __str__(self):
        return str(self.title)


class Tag(models.Model):
    title = models.CharField(max_length=75)
    slug = models.SlugField(unique=True)

    def __str__(self):
        return str(self.title)


class Notelist(models.Model):
    name = models.CharField(max_length=75)
    added_date = models.DateTimeField(auto_now_add=True)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    tag = models.ManyToManyField(Tag)
    description = RichTextField(blank=True, null=True)
    priority = models.ForeignKey(Status, on_delete=models.CASCADE)
    author = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return str(self.name)


class Done(models.Model):
    name = models.CharField(max_length=75)
    added_date = models.DateTimeField(auto_now_add=True)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    tag = models.ManyToManyField(Tag)
    description = RichTextField(blank=True, null=True)
    priority = models.ForeignKey(Status, on_delete=models.CASCADE)
    author = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return str(self.name)
