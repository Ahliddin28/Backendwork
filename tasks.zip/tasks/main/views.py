from django.shortcuts import render, redirect
from django.views.generic import TemplateView, ListView
from .models import *
from django.views.generic.edit import UpdateView, CreateView
from django.urls import reverse_lazy

# Create your views here.


class HomePageView(ListView):
    template_name = 'index.html'

    def get(self, request, *args, **kwargs):
        notes = Notelist.objects.all()
        dones = Done.objects.all()
        data = {
            "notes": notes,
            'dones': dones
        }

        return render(request, self.template_name, context=data)


class AddView(CreateView):
    model = Notelist
    templates_name = 'notelist_form.html'
    fields = ['name', 'description', 'category', 'tag', 'priority']
    success_url = '/'

    def form_valid(self, form):
        form.instance.author = self.request.user
        return super().form_valid(form)


class UpdateView(UpdateView):
    model = Notelist
    template_name = 'main/notelist_form.html'
    fields = ['name', 'description', 'category', 'tag', 'priority']
    success_url = '/'


def not_foud_page(request, exception):
    return render(request, '404.html')


def UpdateNote(request, pk):
    objects = Notelist.objects.all()
    context = {
        'object_list': objects
    }
    return render(request, 'update.html', context)


def done(request, pk):
    Notes = Notelist.objects.get(id=pk)
    Dones = Done.objects.create(name=Notes.name, added_date=Notes.added_date, category=Notes.category,
                                description=Notes.description, priority=Notes.priority, author=Notes.author)
    Notes.delete()
    context = {
        "notes": Notes,
        'dones': Dones
    }
    return redirect('/', context)


def delete(request, pk):
    note = Done.objects.get(id=pk)
    note.delete()
    return redirect('/')


class HelpPage(TemplateView):
    template_name = 'help.html'



